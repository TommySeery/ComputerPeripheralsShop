
public class Admin extends User{

	public Admin(int id, String username, String name, Address addr) {
		super(id,username,name,addr);
	}
	
	
	
}
